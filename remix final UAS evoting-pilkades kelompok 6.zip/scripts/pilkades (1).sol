// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract PilkadesBlockchain {
    struct Candidate {
        uint id;
        string name;
        uint voteCount;
    }

    address public panitia;
    mapping(uint => Candidate) public candidates;
    uint public candidatesCount;

    mapping(address => bool) public hasVoted;
    mapping(address => bool) public isRegistered;

    event VoterRegistered(address indexed voterAddress);
    event VoteCast(address indexed voterAddress, uint indexed candidateId);

    constructor() {
        panitia = msg.sender;
        addCandidate("Yusuf Islam");
        addCandidate("Raehan Zaki");
        addCandidate("Ade Nafila");
        addCandidate("Amanda Juliana"); 
    }

    function addCandidate(string memory _name) private {
        candidatesCount++;
        candidates[candidatesCount] = Candidate(candidatesCount, _name, 0);
    }

    function registerVoter(address _voterAddress) public {
        require(msg.sender == panitia, "Hanya panitia yang bisa mendaftarkan warga");
        require(!isRegistered[_voterAddress], "Warga ini sudah terdaftar!");
        
        isRegistered[_voterAddress] = true;

        emit VoterRegistered(_voterAddress);
    }

    function castVote(uint _candidateId) public {
        require(isRegistered[msg.sender], "Wallet Anda belum didaftarkan panitia");
        require(!hasVoted[msg.sender], "Anda sudah menggunakan hak suara");
        require(_candidateId > 0 && _candidateId <= candidatesCount, "ID Kandidat tidak sah");

        hasVoted[msg.sender] = true;
        candidates[_candidateId].voteCount++;

        emit VoteCast(msg.sender, _candidateId);
    }

    function getResults() public view returns (uint[] memory) {
        uint[] memory results = new uint[](candidatesCount);
        
        for (uint i = 1; i <= candidatesCount; i++) {
            results[i - 1] = candidates[i].voteCount;
        }
        
        return results;
    }
}
// ==========================================
// 1. INISIALISASI FIREBASE (DATABASE OFF-CHAIN)
// ==========================================
const firebaseConfig = {
    apiKey: "AIzaSyA6k8N-qGAKc1eicYHjkrmi0BlMb5n6m8Q",
    authDomain: "evoting-pilkades.firebaseapp.com",
    projectId: "evoting-pilkades",
    storageBucket: "evoting-pilkades.firebasestorage.app",
    messagingSenderId: "307265420092",
    appId: "1:307265420092:web:1575abb562a64963e3bc39"
};

// Mulai Firebase & Firestore
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();


// ==========================================
// 2. KONFIGURASI SMART CONTRACT (ON-CHAIN)
// ==========================================
const contractAddress = "0xbA20A24dE5C004338b88bf63af085C9323196e98 ";

const contractABI = [
    "function registerVoter(address _voterAddress) public",
    "function castVote(uint _candidateId) public",
    "function hasVoted(address) public view returns (bool)",
    "function isRegistered(address) public view returns (bool)" // Ditambahkan untuk cek status warga
];


// ==========================================
// 3. ELEMEN HTML
// ==========================================
const loginBtn = document.getElementById('loginBtn');
const nikInput = document.getElementById('nikInput');
const loginPage = document.getElementById('loginPage');
const votingPage = document.getElementById('votingPage');


// ==========================================
// 4. LOGIKA LOGIN (CEK NIK & METAMASK)
// ==========================================
loginBtn.addEventListener('click', async () => {
    const nikValue = nikInput.value.trim();

    if (nikValue === "") {
        alert("Silakan masukkan NIK terlebih dahulu!");
        return; 
    }

    if (typeof window.ethereum === 'undefined') {
        alert("MetaMask tidak terdeteksi! Silakan install ekstensi MetaMask di browsermu.");
        return;
    }

    try {
        loginBtn.innerHTML = "⏳ Memeriksa NIK...";
        loginBtn.disabled = true;

        // TAHAP 1: Cek NIK di Database Firebase (Dukcapil/Panitia)
        const docRef = await db.collection("warga").doc(nikValue).get();

        if (!docRef.exists) {
            alert("❌ AKSES DITOLAK: NIK Anda tidak ditemukan di database Panitia!");
            resetLoginButton();
            return;
        }

        // TAHAP 2: Tarik alamat wallet yang terikat dengan NIK tersebut
        const dataWarga = docRef.data();
        const walletTerdaftar = dataWarga.walletAddress.toLowerCase();

        // TAHAP 3: Buka MetaMask dan ambil alamat aktif warga
        loginBtn.innerHTML = "🦊 Membuka MetaMask...";
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const accounts = await provider.send("eth_requestAccounts", []);
        const userWallet = accounts[0].toLowerCase();

        // TAHAP 4: Cocokkan Wallet MetaMask dengan Wallet di Database Firebase
        if (userWallet !== walletTerdaftar) {
            alert("❌ AKSES DITOLAK: Dompet MetaMask yang digunakan tidak cocok dengan NIK Anda!");
            resetLoginButton();
            return;
        }

        // TAHAP 5: Cek apakah panitia sudah mendaftarkannya di Smart Contract (Whitelist)
        loginBtn.innerHTML = "⏳ Verifikasi Blockchain...";
        const pilkadesContract = new ethers.Contract(contractAddress, contractABI, provider);
        const sudahTerdaftarDiBlockchain = await pilkadesContract.isRegistered(userWallet);

        if (!sudahTerdaftarDiBlockchain) {
            alert("❌ AKSES DITOLAK: NIK valid, tapi Anda belum di-whitelist oleh panitia di Blockchain.");
            resetLoginButton();
            return;
        }

        // BERHASIL LOLOS SEMUA UJIAN!
        loginBtn.innerHTML = "✅ Terhubung!";
        loginBtn.style.backgroundColor = "#10b981"; 

        // Pindah halaman
        setTimeout(() => {
            loginPage.style.display = 'none'; 
            votingPage.style.display = 'block'; 
        }, 1000);

    } catch (error) {
        console.error("Gagal saat proses login:", error);
        alert("Terjadi kesalahan sistem atau batal terhubung ke MetaMask.");
        resetLoginButton();
    }
});

function resetLoginButton() {
    loginBtn.disabled = false;
    loginBtn.style.backgroundColor = ""; // Kembalikan warna awal
    loginBtn.innerHTML = `
        <span class="metamask-icon">🦊</span>
        <div class="btn-text-wrapper">
            <span>Verifikasi & Masuk</span>
            <small>Gunakan MetaMask</small>
        </div>
    `;
}


// ==========================================
// 5. LOGIKA PEMILIHAN (VOTING) & POP-UP MODAL
// ==========================================
let selectedCandidateId = null;

function selectCandidate(id, cardElement) {
    selectedCandidateId = id;

    const allCards = document.querySelectorAll('.candidate-card');
    allCards.forEach(card => card.classList.remove('selected'));

    cardElement.classList.add('selected');

    const submitBtn = document.getElementById('submitVoteBtn');
    submitBtn.disabled = false;
}

const candidateNames = {
    1: "Yusuf Islam",
    2: "Raehan Rahmat Zaki",
    3: "Ade Nafila",
    4: "Amanda Juliana Putri"
};

const customModal = document.getElementById('customMetaMaskModal');

// Buka pop-up buatan sendiri
document.getElementById('submitVoteBtn').addEventListener('click', () => {
    if(selectedCandidateId !== null) {
        document.getElementById('modalCandidateName').innerText = candidateNames[selectedCandidateId];
        customModal.style.display = 'flex';
    }
});

// Tutup pop-up
document.getElementById('btnTolak').addEventListener('click', () => {
    customModal.style.display = 'none';
});

// Tanda Tangani & Eksekusi Web3
document.getElementById('btnTandaTangani').addEventListener('click', async () => {
    
    customModal.style.display = 'none';
    
    const submitBtn = document.getElementById('submitVoteBtn');
    submitBtn.innerHTML = "⏳ Membuka MetaMask Asli...";
    submitBtn.disabled = true;

    try {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const pilkadesContract = new ethers.Contract(contractAddress, contractABI, signer);

        const transaction = await pilkadesContract.castVote(selectedCandidateId);

        submitBtn.innerHTML = "⏳ Menunggu Konfirmasi Jaringan...";
        await transaction.wait(); 

        document.getElementById('votingPage').style.display = 'none';
        const successPage = document.getElementById('successPage');
        successPage.style.display = 'flex';

        const hashAwal = transaction.hash.substring(0, 15);
        const hashAkhir = transaction.hash.substring(transaction.hash.length - 4);
        document.getElementById('txHashDisplay').innerText = hashAwal + "..." + hashAkhir;
        document.getElementById('etherscanLink').href = "https://sepolia.etherscan.io/tx/" + transaction.hash;

        document.getElementById('copyHashBtn').onclick = () => {
            navigator.clipboard.writeText(transaction.hash);
            alert("Kode Hash Transaksi berhasil disalin!");
        };

    } catch (error) {
        console.error("Gagal mengirim suara:", error);
        if (error.data && error.data.message) {
            alert("Transaksi Gagal: " + error.data.message);
        } else {
            alert("Transaksi dibatalkan.");
        }
        submitBtn.innerHTML = "Kirim Suara";
        submitBtn.disabled = false;
    }
});
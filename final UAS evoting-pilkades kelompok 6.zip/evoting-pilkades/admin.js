// ==========================================
// 1. INISIALISASI FIREBASE & CONTRACT
// ==========================================
// Konfigurasi Firebase (dari langkah sebelumnya)
const firebaseConfig = {
    apiKey: "AIzaSyA6k8N-qGAKc1eicYHjkrmi0BlMb5n6m8Q",
    authDomain: "evoting-pilkades.firebaseapp.com",
    projectId: "evoting-pilkades",
    storageBucket: "evoting-pilkades.firebasestorage.app",
    messagingSenderId: "307265420092",
    appId: "1:307265420092:web:1575abb562a64963e3bc39"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// Konfigurasi Smart Contract
const contractAddress = "0xbA20A24dE5C004338b88bf63af085C9323196e98"; 
const contractABI = [
    "function registerVoter(address _voterAddress) public",
    "function getResults() public view returns (uint256[] memory)"
];

const registerBtn = document.getElementById('registerBtn');
const statusText = document.getElementById('adminStatus');
const historyList = document.querySelector('.history-list');

// ==========================================
// 2. FUNGSI MENGAMBIL DATA LIVE (CHART)
// ==========================================
async function fetchLiveResults() {
    try {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const pilkadesContract = new ethers.Contract(contractAddress, contractABI, provider);

        const results = await pilkadesContract.getResults();
        
        const votes = [
            results[0].toNumber(),
            results[1].toNumber(),
            results[2].toNumber(),
            results[3].toNumber()
        ];

        const totalVotes = votes.reduce((a, b) => a + b, 0);
        document.getElementById('totalVotesDisplay').innerText = totalVotes;

        if (totalVotes === 0) return; 

        let percents = votes.map(v => ((v / totalVotes) * 100).toFixed(0));

        for(let i = 0; i < 4; i++) {
            document.getElementById(`voteCount${i+1}`).innerText = `${votes[i]} Suara`;
            document.getElementById(`votePercent${i+1}`).innerText = `${percents[i]}%`;
        }

        const p1 = parseFloat(percents[0]);
        const p2 = p1 + parseFloat(percents[1]);
        const p3 = p2 + parseFloat(percents[2]);
        
        const pieChart = document.querySelector('.css-pie-chart');
        pieChart.style.background = `conic-gradient(
            #7c3aed 0% ${p1}%,    
            #eab308 ${p1}% ${p2}%,   
            #0d9488 ${p2}% ${p3}%,   
            #be123c ${p3}% 100%   
        )`;
    } catch (error) {
        console.error("Gagal memuat hasil live:", error);
    }
}

// ==========================================
// 3. FUNGSI RIWAYAT DARI FIREBASE
// ==========================================
async function loadHistoryFromFirebase() {
    historyList.innerHTML = ""; 
    const snapshot = await db.collection("registrations").orderBy("timestamp", "desc").get();
    
    if (snapshot.empty) {
        historyList.innerHTML = '<p style="color: #6b7280; font-size: 14px;">Belum ada pendaftaran di sesi ini.</p>';
        return;
    }

    snapshot.forEach(doc => {
        const data = doc.data();
        const historyItem = document.createElement('div');
        historyItem.className = 'history-item';
        historyItem.innerHTML = `
            <div class="wallet-info">
                <span>🪪</span> ${data.wallet.substring(0, 10)}...${data.wallet.substring(data.wallet.length - 4)}
            </div>
            <div class="status-success">✅ Successful</div>
        `;
        historyList.appendChild(historyItem);
    });
}

// ==========================================
// 4. FUNGSI DAFTAR PEMILIH (BLOCKCHAIN + FIREBASE)
// ==========================================
registerBtn.addEventListener('click', async () => {
    const voterAddress = document.getElementById('voterAddressInput').value.trim();

    if (!voterAddress) {
        alert("Harap masukkan alamat dompet warga!");
        return;
    }

    try {
        registerBtn.innerHTML = "⏳ Memproses...";
        registerBtn.disabled = true;
        statusText.innerText = "Membuka MetaMask...";

        const provider = new ethers.providers.Web3Provider(window.ethereum);
        await provider.send("eth_requestAccounts", []); 
        const signer = provider.getSigner();
        const pilkadesContract = new ethers.Contract(contractAddress, contractABI, signer);

        statusText.innerText = "Mendaftarkan ke Blockchain...";
        const transaction = await pilkadesContract.registerVoter(voterAddress);
        await transaction.wait();

        // Simpan ke Firebase
        await db.collection("registrations").add({
            wallet: voterAddress,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        });

        statusText.innerText = "✅ Berhasil Didaftarkan!";
        document.getElementById('voterAddressInput').value = ""; 
        
        loadHistoryFromFirebase(); // Update daftar di layar

    } catch (error) {
        console.error("Gagal mendaftar:", error);
        statusText.innerText = "❌ Gagal: Pastikan Anda Akun Panitia!";
    } finally {
        registerBtn.innerHTML = "Daftarkan Pemilih";
        registerBtn.disabled = false;
    }
});

// Load saat pertama kali buka
window.addEventListener('load', () => {
    fetchLiveResults();
    loadHistoryFromFirebase();
});